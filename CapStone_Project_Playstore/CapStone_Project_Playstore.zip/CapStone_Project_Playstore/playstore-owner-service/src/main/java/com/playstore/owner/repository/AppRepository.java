package com.playstore.owner.repository;

import com.playstore.owner.entity.App;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AppRepository extends JpaRepository<App, Long> {

    List<App> findByNameContainingIgnoreCase(String name);

    List<App> findByCategoryIgnoreCase(String category);

    List<App> findByNameContainingIgnoreCaseOrDescriptionContainingIgnoreCase(
            String name, String description
    );

    // NEW: filter by rating
    List<App> findByAverageRatingGreaterThanEqual(Double rating);
    
}
