package com.playstore.owner.service;

import com.playstore.owner.entity.App;
import com.playstore.owner.repository.AppRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppServiceImpl implements AppService {

    private final AppRepository appRepository;

    public AppServiceImpl(AppRepository appRepository) {
        this.appRepository = appRepository;
    }

    @Override
    public App createApp(App app) {
        return appRepository.save(app);
    }

    @Override
    public List<App> getAllApps() {
        return appRepository.findAll();
    }

    @Override
    public App updateApp(Long id, App app) {
        App existing = appRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("App not found"));
        existing.setName(app.getName());
        existing.setDescription(app.getDescription());
        existing.setCategory(app.getCategory());
        existing.setVersion(app.getVersion());
        existing.setReleaseDate(app.getReleaseDate());
        existing.setVisible(app.getVisible());
        existing.setAverageRating(app.getAverageRating());
        return appRepository.save(existing);
    }

    @Override
    public void deleteApp(Long id) {
        appRepository.deleteById(id);
    }

    @Override
    public List<App> searchByName(String name) {
        return appRepository.findByNameContainingIgnoreCase(name);
    }

    @Override
    public List<App> searchByCategory(String category) {
    	return appRepository.findByCategoryIgnoreCase(category);

    }

    @Override
    public long getDownloadCount(Long appId) {
        // your existing logic that calls user-service
        return 0L;
    }

    @Override
    public App changeVisibility(Long id, Boolean visible) {
        App app = appRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("App not found"));
        app.setVisible(visible);
        return appRepository.save(app);
    }

    @Override
    public List<App> filterByRating(Double minRating) {
        // assuming you have custom repo method
        return appRepository.findByAverageRatingGreaterThanEqual(minRating);
    }

    @Override
    public void updateRating(Long appId, Double avg) {
        App app = appRepository.findById(appId)
                .orElseThrow(() -> new RuntimeException("App not found"));
        app.setAverageRating(avg);
        appRepository.save(app);
    }
}
