package com.playstore.owner.exception;

public class InvalidOwnerCredentialsException extends RuntimeException {

    public InvalidOwnerCredentialsException(String message) {
        super(message);
    }
}
