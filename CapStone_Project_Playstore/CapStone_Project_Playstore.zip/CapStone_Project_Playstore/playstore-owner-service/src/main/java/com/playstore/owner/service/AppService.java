package com.playstore.owner.service;

import com.playstore.owner.entity.App;
import java.util.List;

public interface AppService {

    App createApp(App app);

    List<App> getAllApps();

    App updateApp(Long id, App app);

    void deleteApp(Long id);

    List<App> searchByName(String name);

    List<App> searchByCategory(String category);

    long getDownloadCount(Long appId);   // will call user-service

    App changeVisibility(Long id, Boolean visible);

    List<App> filterByRating(Double minRating);

    void updateRating(Long appId, Double avg);
}
