package com.playstore.owner.controller;

import com.playstore.owner.entity.Owner;
import com.playstore.owner.security.JwtUtil;
import com.playstore.owner.service.OwnerService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class OwnerAuthController {

    private final OwnerService ownerService;
    private final JwtUtil jwtUtil;

    public OwnerAuthController(OwnerService ownerService, JwtUtil jwtUtil) {
        this.ownerService = ownerService;
        this.jwtUtil = jwtUtil;
    }

    @GetMapping("/owner/login-page")
    public String showLoginPage() {
        return "owner-auth";          // owner-auth.html
    }
    @GetMapping("/owner/register-page")
    public String showRegisterPage() {
        return "owner-register";   // owner-register.html
    }


    
    @PostMapping("/owner/register")
    public String handleRegister(@RequestParam Long ownerId,
                                 @RequestParam String fullName,
                                 @RequestParam String email,
                                 @RequestParam String password,
                                 Model model) {
        try {
            Owner owner = new Owner();
            owner.setOwnerId(ownerId);
            owner.setFullName(fullName);
            owner.setEmail(email);
            owner.setPassword(password);
            owner.setRole("OWNER");

            ownerService.registerOwner(owner);

            model.addAttribute("success", "Registration successful! Please login.");
            return "owner-auth";
        } catch (Exception ex) {
            model.addAttribute("error", "Registration failed: " + ex.getMessage());
            return "owner-register";
        }
    }

    @PostMapping("/owner/login")
    public String handleLogin(@RequestParam String email,
                              @RequestParam String password,
                              HttpSession session,
                              Model model) {

        Owner owner = ownerService.validateOwner(email, password);

        if (owner == null) {
            model.addAttribute("error", "Invalid email or password");
            return "owner-auth";
        }

        String token = jwtUtil.generateToken(owner.getEmail());
        session.setAttribute("jwtToken", token);
        session.setAttribute("loggedInOwner", owner.getEmail());

        return "redirect:/owner/home";
    }
}
