package com.playstore.owner.service;

import com.playstore.owner.entity.Owner;

import java.util.Optional;

public interface OwnerService {

    Owner registerOwner(Owner owner);

    Optional<Owner> findByEmail(String email);

    // validate email + password, return null if invalid
    default Owner validateOwner(String email, String password) {
        Optional<Owner> optional = findByEmail(email);
        if (optional.isEmpty()) {
            return null;
        }
        Owner owner = optional.get();
        if (!owner.getPassword().equals(password)) {
            return null;
        }
        return owner;
    }

    // helper to get owner or throw (useful with JWT username)
    default Owner getRequiredOwnerByEmail(String email) {
        return findByEmail(email)
                .orElseThrow(() -> new IllegalArgumentException("Owner not found: " + email));
    }
}
