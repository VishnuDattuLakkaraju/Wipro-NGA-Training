package com.playstore.owner.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class OwnerPageController {

    @GetMapping("/owner/home")
    public String showHomePage(HttpSession session, Model model) {
        String email = (String) session.getAttribute("loggedInOwner");
        model.addAttribute("loggedInOwner", email);
        return "owner-home";
    }

    @GetMapping("/owner/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/owner/login-page";
    }
}
