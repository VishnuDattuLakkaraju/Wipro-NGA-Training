package com.playstore.owner.dto;

public class AppDto {
    private Long id;
    private String name;
    private String description;
    private String category;
    private String version;
    private String releaseDate;
    private Boolean visible;
    private Long downloadCount;
    private Double averageRating;   // NEW

    public AppDto() {}

    public AppDto(Long id, String name, String description,
                  String category, String version, String releaseDate,
                  Boolean visible, Long downloadCount, Double averageRating) { // NEW
        this.id = id;
        this.name = name;
        this.description = description;
        this.category = category;
        this.version = version;
        this.releaseDate = releaseDate;
        this.visible = visible;
        this.downloadCount = downloadCount;
        this.averageRating = averageRating;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getVersion() { return version; }
    public void setVersion(String version) { this.version = version; }

    public String getReleaseDate() { return releaseDate; }
    public void setReleaseDate(String releaseDate) { this.releaseDate = releaseDate; }

    public Boolean getVisible() { return visible; }
    public void setVisible(Boolean visible) { this.visible = visible; }

    public Long getDownloadCount() { return downloadCount; }
    public void setDownloadCount(Long downloadCount) { this.downloadCount = downloadCount; }

    public Double getAverageRating() { return averageRating; }
    public void setAverageRating(Double averageRating) { this.averageRating = averageRating; }
}
