package com.playstore.owner.controller;

import com.playstore.owner.dto.AppDto;
import com.playstore.owner.entity.App;
import com.playstore.owner.service.AppService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/apps")
public class AppController {

    private final AppService appService;

    public AppController(AppService appService) {
        this.appService = appService;
    }

    @PostMapping
    public ResponseEntity<AppDto> createApp(@RequestBody AppDto appDto) {
        App app = toEntity(appDto);
        App saved = appService.createApp(app);
        return new ResponseEntity<>(toDto(saved), HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<AppDto>> getAllApps() {
        List<App> apps = appService.getAllApps();
        List<AppDto> dtos = apps.stream().map(this::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AppDto> updateApp(@PathVariable Long id,
                                            @RequestBody AppDto appDto) {
        App updated = appService.updateApp(id, toEntity(appDto));
        return ResponseEntity.ok(toDto(updated));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteApp(@PathVariable Long id) {
        appService.deleteApp(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search/by-name")
    public ResponseEntity<List<AppDto>> searchByName(@RequestParam String name) {
        List<App> apps = appService.searchByName(name);
        List<AppDto> dtos = apps.stream().map(this::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/search/by-category")
    public ResponseEntity<List<AppDto>> searchByCategory(@RequestParam String category) {
        List<App> apps = appService.searchByCategory(category);
        List<AppDto> dtos = apps.stream().map(this::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    @GetMapping("/{id}/downloads/count")
    public long getDownloadCount(@PathVariable Long id) {
        return appService.getDownloadCount(id);
    }

    @PatchMapping("/{id}/visibility")
    public ResponseEntity<AppDto> changeVisibility(@PathVariable Long id,
                                                   @RequestParam Boolean visible) {
        App updated = appService.changeVisibility(id, visible);
        return ResponseEntity.ok(toDto(updated));
    }

    // NEW: filter by rating
    @GetMapping("/filter/by-rating")
    public ResponseEntity<List<AppDto>> filterByRating(@RequestParam Double minRating) {
        List<App> apps = appService.filterByRating(minRating);
        List<AppDto> dtos = apps.stream().map(this::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(dtos);
    }

    private AppDto toDto(App app) {
        Long count = appService.getDownloadCount(app.getAppId());

        return new AppDto(
                app.getAppId(),
                app.getName(),
                app.getDescription(),
                app.getCategory(),
                app.getVersion(),
                app.getReleaseDate(),
                app.getVisible(),
                count,
                app.getAverageRating()   // NEW
        );
    }

    private App toEntity(AppDto dto) {
        App app = new App();
        app.setAppId(dto.getId());
        app.setName(dto.getName());
        app.setDescription(dto.getDescription());
        app.setCategory(dto.getCategory());
        app.setVersion(dto.getVersion());
        app.setReleaseDate(dto.getReleaseDate());
        app.setVisible(dto.getVisible());
        app.setAverageRating(dto.getAverageRating()); // NEW
        return app;
    }
}
