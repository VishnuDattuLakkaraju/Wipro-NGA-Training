package com.playstore.notification;

import com.playstore.notification.service.EmailService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@SpringBootApplication
public class NotificationServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(NotificationServiceApplication.class, args);
    }

    @Bean
    public CommandLineRunner testMail(EmailService emailService) {
        return args -> {
            // test once when app starts
            // put your Mailtrap inbox email here
            emailService.sendEmail("YOUR_INBOX@example.com",
                    "Test from notification-service",
                    "If you see this, email works.");
        };
    }
}
