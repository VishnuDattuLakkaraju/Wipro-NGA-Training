package com.playstore.notification.controller;

import com.playstore.notification.service.EmailService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final EmailService emailService;

    public NotificationController(EmailService emailService) {
        this.emailService = emailService;
    }

    // already used for simple test
    @PostMapping("/test")
    public ResponseEntity<Void> test(@RequestParam String to) {
        emailService.sendEmail(to, "Test from API", "API call works.");
        return ResponseEntity.ok().build();
    }

    // Owner notified when app is downloaded (you already use this)
    @PostMapping("/app-download")
    public ResponseEntity<Void> notifyAppDownload(
            @RequestParam String ownerEmail,
            @RequestParam String appName,
            @RequestParam String userEmail) {

        String subject = "Your app was downloaded: " + appName;
        String body = "User " + userEmail + " downloaded your app " + appName + ".";
        emailService.sendEmail(ownerEmail, subject, body);
        return ResponseEntity.ok().build();
    }

    // NEW: users notified when app is updated
    @PostMapping("/app-update")
    public ResponseEntity<Void> notifyAppUpdate(
            @RequestParam String appName,
            @RequestParam String version,
            @RequestParam String userEmail) {

        String subject = "Update available for " + appName;
        String body = "New version " + version + " is available for " + appName + ".";
        emailService.sendEmail(userEmail, subject, body);
        return ResponseEntity.ok().build();
    }
}
