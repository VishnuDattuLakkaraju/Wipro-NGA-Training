package com.playstore.discovery;

import org.springframework.boot.SpringApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableEurekaServer
public class PlaystoreDiscoveryServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaystoreDiscoveryServerApplication.class, args);
	}

}
