package com.playstore.user.service;

import com.playstore.user.entity.User;
import com.playstore.user.repository.DownloadRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class AppUpdateService {

    private final RestTemplate restTemplate;
    private final DownloadRepository downloadRepository;
    private final UserService userService;

    public AppUpdateService(RestTemplate restTemplate,
                            DownloadRepository downloadRepository,
                            UserService userService) {
        this.restTemplate = restTemplate;
        this.downloadRepository = downloadRepository;
        this.userService = userService;
    }

    // Called when owner announces an update for an app
    public void announceUpdate(Long appId, String version) {
        // TODO: later call app-service to get real app name from appId
        String appName = "TestApp";

        // 1) all users who downloaded this app
        List<Long> userIds = downloadRepository.findDistinctUserIdsByAppId(appId);
        if (userIds.isEmpty()) {
            System.out.println("No downloaders for appId = " + appId);
            return;
        }

        // 2) load user entities and emails
        List<User> users = userService.getUsersByIds(userIds);

        // 3) send update email to each
        for (User u : users) {
            String email = u.getEmail();
            System.out.println("Sending update to: " + email);
            notifyAppUpdate(appName, version, email);
        }
    }

    private void notifyAppUpdate(String appName, String version, String userEmail) {
        String url = "http://localhost:8083/api/notifications/app-update"
                + "?appName={app}&version={ver}&userEmail={user}";

        restTemplate.postForObject(
                url,
                null,
                Void.class,
                appName,
                version,
                userEmail
        );
    }
}
