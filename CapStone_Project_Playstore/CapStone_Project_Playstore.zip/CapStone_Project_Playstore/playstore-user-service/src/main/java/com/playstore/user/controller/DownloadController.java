package com.playstore.user.controller;

import com.playstore.user.service.DownloadService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/downloads")
public class DownloadController {

    private final DownloadService downloadService;

    public DownloadController(DownloadService downloadService) {
        this.downloadService = downloadService;
    }

    @PostMapping("/record")
    public void record(@RequestParam Long appId,
                       @RequestParam Long userId) {
        downloadService.recordDownload(appId, userId);
    }

    @GetMapping("/count")
    public long getCount(@RequestParam Long appId) {
        return downloadService.getDownloadCount(appId);
    }
}

