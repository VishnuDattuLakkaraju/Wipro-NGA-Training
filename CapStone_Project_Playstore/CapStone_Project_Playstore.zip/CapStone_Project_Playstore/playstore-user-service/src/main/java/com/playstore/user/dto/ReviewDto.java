package com.playstore.user.dto;

public class ReviewDto {
    private Long id;
    private Long appId;
    private String comment;
    private int rating;
    private String username;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getAppId() { return appId; }
    public void setAppId(Long appId) { this.appId = appId; }

    public String getComment() { return comment; }
    public void setComment(String comment) { this.comment = comment; }

    public int getRating() { return rating; }
    public void setRating(int rating) { this.rating = rating; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
}
