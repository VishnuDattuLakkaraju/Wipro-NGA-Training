package com.playstore.user.service;

public interface DownloadService {

    void recordDownload(Long appId, Long userId);

    long getDownloadCount(Long appId);
}
