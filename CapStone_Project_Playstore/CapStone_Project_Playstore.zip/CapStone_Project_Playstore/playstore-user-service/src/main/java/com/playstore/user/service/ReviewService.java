package com.playstore.user.service;

import com.playstore.user.entity.Review;
import java.util.List;

public interface ReviewService {

    Review addReview(Review review);

    List<Review> getReviewsByAppId(Long appId);
}
