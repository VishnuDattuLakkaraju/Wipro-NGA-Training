package com.playstore.user.controller;

import com.playstore.user.dto.ReviewDto;
import com.playstore.user.entity.Review;
import com.playstore.user.entity.User;
import com.playstore.user.service.ReviewService;
import com.playstore.user.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    private final ReviewService reviewService;
    private final UserService userService;

    public ReviewController(ReviewService reviewService, UserService userService) {
        this.reviewService = reviewService;
        this.userService = userService;
    }

    @GetMapping("/app/{appId}")
    public List<ReviewDto> getReviewsForApp(@PathVariable Long appId) {
        List<Review> reviews = reviewService.getReviewsByAppId(appId);
        return reviews.stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @PostMapping
    public ReviewDto addReview(@RequestBody ReviewDto dto,
                               HttpSession session) {

        Long userId = (Long) session.getAttribute("loggedInUserId");
        if (userId == null) {
            throw new RuntimeException("User not logged in");
        }

        Review review = new Review();
        review.setAppId(dto.getAppId());
        review.setUserId(userId);
        review.setRating(dto.getRating());
        review.setComment(dto.getComment());

        Review saved = reviewService.addReview(review);
        return toDto(saved);
    }

    private ReviewDto toDto(Review r) {
        ReviewDto dto = new ReviewDto();
        dto.setId(r.getReviewId());
        dto.setAppId(r.getAppId());
        dto.setComment(r.getComment());
        dto.setRating(r.getRating());

        User u = userService.getUserById(r.getUserId());
        dto.setUsername(u != null ? u.getEmail() : "Unknown");

        return dto;
    }
}
