package com.playstore.user.repository;

import com.playstore.user.entity.Download;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DownloadRepository extends JpaRepository<Download, Long> {

    long countByAppId(Long appId);

    @Query("select distinct d.userId from Download d where d.appId = :appId")
    List<Long> findDistinctUserIdsByAppId(Long appId);
}
