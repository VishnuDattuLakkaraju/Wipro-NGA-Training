package com.playstore.user.service;

import com.playstore.user.dto.AppDto;
import java.util.List;

public interface UserAppService {
List<AppDto> getVisibleApps();
}