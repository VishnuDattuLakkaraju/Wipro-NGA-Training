package com.playstore.user.dto;

public class AppDto {

    private Long appId;
    private String name;
    private String description;
    private String category;
    private Double price;
    private Boolean visible;
    private Long downloadCount;   // NEW

    public AppDto() {
    }

    public AppDto(Long appId,
                  String name,
                  String description,
                  String category,
                  Double price,
                  Boolean visible,
                  Long downloadCount) {
        this.appId = appId;
        this.name = name;
        this.description = description;
        this.category = category;
        this.price = price;
        this.visible = visible;
        this.downloadCount = downloadCount;
    }

    public Long getAppId() {
        return appId;
    }

    public void setAppId(Long appId) {
        this.appId = appId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public Boolean getVisible() {
        return visible;
    }

    public void setVisible(Boolean visible) {
        this.visible = visible;
    }

    public Long getDownloadCount() {
        return downloadCount;
    }

    public void setDownloadCount(Long downloadCount) {
        this.downloadCount = downloadCount;
    }
}
