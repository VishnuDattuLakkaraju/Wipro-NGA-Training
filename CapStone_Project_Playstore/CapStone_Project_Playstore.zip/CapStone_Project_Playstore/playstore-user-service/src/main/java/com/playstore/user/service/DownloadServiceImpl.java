package com.playstore.user.service;

import com.playstore.user.entity.Download;
import com.playstore.user.repository.DownloadRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class DownloadServiceImpl implements DownloadService {

    private final DownloadRepository downloadRepository;

    public DownloadServiceImpl(DownloadRepository downloadRepository) {
        this.downloadRepository = downloadRepository;
    }

    @Override
    public void recordDownload(Long appId, Long userId) {
        Download d = new Download();
        d.setAppId(appId);
        d.setUserId(userId);
        d.setDownloadedAt(LocalDateTime.now());
        downloadRepository.save(d);
    }

    @Override
    public long getDownloadCount(Long appId) {
        return downloadRepository.countByAppId(appId);
    }
}
