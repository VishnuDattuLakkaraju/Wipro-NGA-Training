package com.playstore.user.controller;

import com.playstore.user.service.AppUpdateService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/apps")
public class AppUpdateController {

    private final AppUpdateService appUpdateService;

    public AppUpdateController(AppUpdateService appUpdateService) {
        this.appUpdateService = appUpdateService;
    }

    // Owner calls this to announce an update for an app
    @PostMapping("/{appId}/update")
    public void announceUpdate(@PathVariable Long appId,
                               @RequestParam String version) {
        appUpdateService.announceUpdate(appId, version);
    }
}
