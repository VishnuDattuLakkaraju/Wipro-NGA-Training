package com.playstore.user.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

@Entity
@Table(name = "reviews")
public class Review {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Long reviewId;

private Long appId;
private Long userId;
private Integer rating;      // 1 to 5
private String comment;
private LocalDateTime createdAt;

public Review() {
}

public Review(Long reviewId, Long appId, Long userId,
              Integer rating, String comment,
              LocalDateTime createdAt) {
    this.reviewId = reviewId;
    this.appId = appId;
    this.userId = userId;
    this.rating = rating;
    this.comment = comment;
    this.createdAt = createdAt;
}

public Long getReviewId() {
    return reviewId;
}

public void setReviewId(Long reviewId) {
    this.reviewId = reviewId;
}

public Long getAppId() {
    return appId;
}

public void setAppId(Long appId) {
    this.appId = appId;
}

public Long getUserId() {
    return userId;
}

public void setUserId(Long userId) {
    this.userId = userId;
}

public Integer getRating() {
    return rating;
}

public void setRating(Integer rating) {
    this.rating = rating;
}

public String getComment() {
    return comment;
}

public void setComment(String comment) {
    this.comment = comment;
}

public LocalDateTime getCreatedAt() {
    return createdAt;
}

public void setCreatedAt(LocalDateTime createdAt) {
    this.createdAt = createdAt;
}
}