package com.playstore.user.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserPageController {

    @GetMapping("/user/login-page")
    public String showLoginPage() {
        return "user-auth";
    }

    @GetMapping("/user/register-page")
    public String showRegisterPage() {
        return "user-register";
    }

    @GetMapping("/user/home")
    public String showHomePage(HttpSession session, Model model) {
        String email = (String) session.getAttribute("loggedInUser");
        Long userId = (Long) session.getAttribute("loggedInUserId"); // must be set at login

        model.addAttribute("loggedInUser", email);
        model.addAttribute("loggedInUserId", userId);

        return "user-home";
    }

    @GetMapping("/user/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/user/login-page";
    }
}
