package com.playstore.user.service;

import com.playstore.user.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {

    User registerUser(User user);

    Optional<User> findByEmail(String email);

    User getUserById(Long userId);

    // NEW: fetch many users for downloads/app updates
    List<User> getUsersByIds(List<Long> userIds);

    default User validateUser(String email, String password) {
        Optional<User> optionalUser = findByEmail(email);
        if (optionalUser.isEmpty()) {
            return null;
        }
        User user = optionalUser.get();
        if (!user.getPassword().equals(password)) {
            return null;
        }
        return user;
    }
}
