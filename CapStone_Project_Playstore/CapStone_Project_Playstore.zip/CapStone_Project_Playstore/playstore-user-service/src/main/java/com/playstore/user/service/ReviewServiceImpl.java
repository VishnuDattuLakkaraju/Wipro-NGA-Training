package com.playstore.user.service;

import com.playstore.user.entity.Review;
import com.playstore.user.repository.ReviewRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@Service
public class ReviewServiceImpl implements ReviewService {

    private final ReviewRepository reviewRepository;
    private final RestTemplate restTemplate;

    public ReviewServiceImpl(ReviewRepository reviewRepository,
                             RestTemplate restTemplate) {
        this.reviewRepository = reviewRepository;
        this.restTemplate = restTemplate;
    }

    @Override
    public Review addReview(Review review) {
        // save review
        Review saved = reviewRepository.save(review);

        // get all reviews for app
        List<Review> reviews = reviewRepository.findByAppId(review.getAppId());

        // compute average
        double avg = reviews.stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0);

        // call owner-service to update app averageRating
        String url = "http://OWNER-SERVICE/api/apps/" + review.getAppId()
                + "/rating?avg=" + avg;
        try {
            restTemplate.patchForObject(url, null, Void.class);
        } catch (Exception e) {
            // don't fail review save if rating update fails
            e.printStackTrace();
        }

        return saved;
    }

    @Override
    public List<Review> getReviewsByAppId(Long appId) {
        return reviewRepository.findByAppId(appId);
    }
}
