package com.playstore.user;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlaystoreUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(PlaystoreUserServiceApplication.class, args);
	}

}
