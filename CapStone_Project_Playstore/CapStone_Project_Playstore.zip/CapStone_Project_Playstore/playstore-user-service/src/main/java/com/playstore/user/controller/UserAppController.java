package com.playstore.user.controller;

import com.playstore.user.dto.AppDto;
import com.playstore.user.service.UserAppService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/user/apps")
public class UserAppController {


private final UserAppService userAppService;

public UserAppController(UserAppService userAppService) {
    this.userAppService = userAppService;
}

@GetMapping("/visible")
public List<AppDto> getVisibleApps() {
    return userAppService.getVisibleApps();
}

@GetMapping("/test")
public String test() {
    return "user-apps-ok";
}
}