package com.playstore.user.controller;

import com.playstore.user.entity.User;
import com.playstore.user.security.JwtUtil;
import com.playstore.user.service.UserService;
import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class UserAuthController {

    private final UserService userService;
    private final JwtUtil jwtUtil;

    public UserAuthController(UserService userService, JwtUtil jwtUtil) {
        this.userService = userService;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/user/register")
    public String handleRegister(@RequestParam Long userId,
                                 @RequestParam String fullName,
                                 @RequestParam String email,
                                 @RequestParam String password,
                                 Model model) {

        try {
            User user = new User();
            user.setUserId(userId);
            user.setFullName(fullName);
            user.setEmail(email);
            user.setPassword(password);
            user.setRole("USER");

            userService.registerUser(user);

            model.addAttribute("success", "Registration successful! Please login.");
            return "user-auth";
        } catch (Exception ex) {
            model.addAttribute("error", "Registration failed: " + ex.getMessage());
            return "user-register";
        }
    }

    @PostMapping("/user/login")
    public String handleLogin(@RequestParam String email,
                              @RequestParam String password,
                              HttpSession session,
                              Model model) {

        User user = userService.validateUser(email, password);

        if (user == null) {
            model.addAttribute("error", "Invalid email or password");
            return "user-auth";
        }

        String token = jwtUtil.generateToken(user.getEmail());
        session.setAttribute("jwtToken", token);
        session.setAttribute("loggedInUser", user.getEmail());
        session.setAttribute("loggedInUserId", user.getUserId()); // added

        return "redirect:/user/home";
    }
}
