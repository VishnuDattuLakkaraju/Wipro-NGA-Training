package com.playstore.user.service;

import com.playstore.user.dto.AppDto;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class UserAppServiceImpl implements UserAppService {


private final RestTemplate restTemplate;

public UserAppServiceImpl(RestTemplate restTemplate) {
    this.restTemplate = restTemplate;
}

@Override
public List<AppDto> getVisibleApps() {
    String url = "http://localhost:8082/api/apps";

    AppDto[] apps = restTemplate.getForObject(url, AppDto[].class);

    if (apps == null) {
        return List.of();
    }

    return Arrays.stream(apps)
            .filter(app -> Boolean.TRUE.equals(app.getVisible()))
            .collect(Collectors.toList());
}
}